/**
 * Proxy
 * Copyright �2008 Loki - All Rights Reserved
 **/

#pragma once

