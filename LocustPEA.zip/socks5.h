/**
 * Proxy
 * Copyright �2008 Loki - All Rights Reserved
 **/

#pragma once

SOCKET socks5_handle( SOCKET Client, char* Buffer );