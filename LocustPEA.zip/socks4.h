/**
 * Proxy
 * Copyright �2008 Loki - All Rights Reserved
 **/

#pragma once

SOCKET socks4_handle( SOCKET Client, char* Buffer );