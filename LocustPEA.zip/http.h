/**
 * Proxy
 * Copyright �2008 Loki - All Rights Reserved
 **/

#pragma once

SOCKET http_handle( SOCKET Client, SOCKET Target, char* Buffer, BOOL* Tunnel );