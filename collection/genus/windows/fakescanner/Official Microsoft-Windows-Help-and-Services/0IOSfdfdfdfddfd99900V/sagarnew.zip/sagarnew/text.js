window.defaultNumber = '+1-800-591-8365';

window.defaultText='<font color="red"> Apple Security Alert </font><br>Unusual Email activity detected, It will disable your iPhone. Immediately call Apple Support to fix it! ';
window.text ={
	'xhamster.com':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'perfectgirls.net':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'gotporn.com':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'anysex.com':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'sex.com':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'bravotube.net':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'mylust.com':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'manporn.xxx':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'anybunny.com':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'txxx.com':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!',
	'findbestsolution.xyz':'Your |%model%| has been locked due to detected illegal activity on |%ref%|! Immediately call Apple Support to unlock it!'
};
