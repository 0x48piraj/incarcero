<?php
$os=$user_os;
$browser=$browser;
if (($os=='Mac1') or ($os=='Mac2'))
{
	header("location:baba/");
}
if ((($os!='Mac1') or ($os!='Mac2')) and ($browser=='Chrome'))
{
	header("location:chrome/");
}
?>