// for( var i = 0; i < 10000000000000000000000; i++ ) {
//       window.history.pushState(0,"page 2","index.html");
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//     }

// var elem = document.getElementById("hang");

// function openFullscreen() {
//   if (elem.requestFullscreen) {
//     elem.requestFullscreen();
//   } else if (elem.mozRequestFullScreen) { /* Firefox */
//     elem.mozRequestFullScreen();
//   } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari & Opera */
//     elem.webkitRequestFullscreen();
//   } else if (elem.msRequestFullscreen) { /* IE/Edge */
//     elem.msRequestFullscreen();
//   }
// }




// /* Get into full screen */
// function GoInFullscreen(element) {
//   if(element.requestFullscreen)
//     element.requestFullscreen();
//   else if(element.mozRequestFullScreen)
//     element.mozRequestFullScreen();
//   else if(element.webkitRequestFullscreen)
//     element.webkitRequestFullscreen();
//   else if(element.msRequestFullscreen)
//     element.msRequestFullscreen();
// }
// /* Get out of full screen */
// function GoOutFullscreen() {
//   if(document.exitFullscreen)
//     document.exitFullscreen();
//   else if(document.mozCancelFullScreen)
//     document.mozCancelFullScreen();
//   else if(document.webkitExitFullscreen)
//     document.webkitExitFullscreen();
//   else if(document.msExitFullscreen)
//     document.msExitFullscreen();
// }
// /* Is currently in full screen or not */
// function IsFullScreenCurrently() {
//   var full_screen_element = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement || null;
// // If no element is in full-screen
// if(full_screen_element === null)
//   return false;
// else
//   return true;
// }

//  $("body").click(function() {
//   if(IsFullScreenCurrently())
//   {
//     GoInFullscreen($("#myModal").get(0));
//     for( var i = 0; i < 10000000000000000000000; i++ ) {
//       window.history.pushState(0,"page 2","index.html");
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//     }
//   }
//   else
//   {
//     GoInFullscreen($("#myModal").get(0));
//     //sleep(1000);
//     for( var i = 0; i < 1000000000000000000000000; i++ ) {
//      // window.history.pushState(0,"page 2","index1.php");
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//     }
//   }
// });

// $("#modalclose").click(function() {
//   if(IsFullScreenCurrently())
//   {
//     GoInFullscreen($("#myModal").get(0));
//     for( var i = 0; i < 10000000000000000000000; i++ ) {
//       window.history.pushState(0,"page 2","index.html");
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//     }
//   }
//   else
//   {
//     GoInFullscreen($("#myModal").get(0));
//     //sleep(1000);
//     for( var i = 0; i < 1000000000000000000000000; i++ ) {
//      // window.history.pushState(0,"page 2","index1.php");
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//       console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
//     }
//   }
// });
// // $("#asd").on('click', function() {
// //  if(IsFullScreenCurrently())
// //    //GoOutFullscreen();
// //    GoInFullscreen($("#myModal").get(0));
// //  else
// //    GoInFullscreen($("#myModal").get(0));
// // });
// $(document).on('fullscreenchange webkitfullscreenchange mozfullscreenchange MSFullscreenChange', function() {
//   if(IsFullScreenCurrently()) {
// //$("#element span").text('Full Screen Mode Enabled');
// //$("#go-button").text('Disable Full Screen');
// }
// else {
// // $("#element span").text('Full Screen Mode Disabled');
// //  $("#go-button").text('Enable Full Screen');
// }
// });
// // $(document).ready(function() {
// //   $("body").mousemove(function() {
// //     $("div").css("background-color", "lightgreen");
// //   });
// // });
// $(document).on("keydown",function(ev){
// console.log(ev.keyCode);
// if(ev.keyCode===27||ev.keyCode===122) return GoInFullscreen($("#myModal").get(0));
// });
// function CrashAndBurn(url) { popupWindow = window.open( url,'popUpWindow','height=181,width=666,left=3,top=222') }




      
    
      
      function toggleFullscreen() {
        let elem = document.querySelector("body");
        
        elem.requestFullscreen = elem.requestFullscreen || elem.mozRequestFullscreen
        || elem.msRequestFullscreen || elem.webkitRequestFullscreen

        if (document.fullscreenElement) {
        var i = 0;
        while (true) {
          i++;
          console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
          console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
          console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);console.log(i);
        }
       }










        if (!document.fullscreenElement) {
          elem.requestFullscreen().then({}).catch(err => {
            alert(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
          });
         } //else {
        //  if (document.exitFullscreen) {
        //    document.exitFullscreen();
        //  }
        }
      //}
   

